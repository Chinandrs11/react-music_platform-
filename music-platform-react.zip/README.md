# Music Platform React

Frontend en React para el proyecto de subida de canciones en MP3 con título y artista,
CRUD de canciones y playlists, con login y registro de usuarios.

- React + Vite
- React Router DOM
- Axios
- Context para manejo de autenticación (token JWT)
- Consume las API de un backend en Node.js / MongoDB

## Requisitos previos

- Node.js 18+
- Backend de Node.js corriendo (por ejemplo en `http://localhost:4000/api`)
  con endpoints como:

  - `POST /api/auth/register`
  - `POST /api/auth/login`
  - `GET /api/songs`
  - `POST /api/songs`
  - `PUT /api/songs/:id`
  - `DELETE /api/songs/:id`
  - `GET /api/playlists`
  - `POST /api/playlists`
  - `PUT /api/playlists/:id`
  - `DELETE /api/playlists/:id`

Ajusta las rutas a las que tenga tu proyecto.

## Configuración

1. Clonar el repositorio:

   ```bash
   git clone TU_REPO_URL
   cd music-platform-react
   ```

2. Instalar dependencias:

   ```bash
   npm install
   ```

3. Configurar la URL del backend (opcional):

   Crea un archivo `.env` en la raíz del proyecto y agrega:

   ```bash
   VITE_API_URL=http://localhost:4000/api
   ```

4. Ejecutar la aplicación en modo desarrollo:

   ```bash
   npm run dev
   ```

5. Abre el navegador en la URL que muestre Vite (por defecto `http://localhost:5173`).

## Páginas

- `/login`: inicio de sesión de usuario.
- `/register`: registro de usuario nuevo.
- `/songs`: CRUD completo de canciones (protegido, requiere login).
- `/playlists`: CRUD completo de playlists (protegido, requiere login).

Puedes usar este frontend como base y adaptarlo al diseño que pide tu profesor.
