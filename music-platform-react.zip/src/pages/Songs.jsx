import React, { useEffect, useState } from "react";
import axios from "axios";
import { useAuth } from "../context/AuthContext";
import SongForm from "../components/SongForm";

const Songs = () => {
  const { API_URL } = useAuth();
  const [songs, setSongs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [editingId, setEditingId] = useState(null);
  const [formSong, setFormSong] = useState({
    title: "",
    artist: "",
    fileUrl: "",
  });

  const fetchSongs = async () => {
    try {
      setLoading(true);
      const { data } = await axios.get(`${API_URL}/songs`);
      setSongs(data);
    } catch (err) {
      console.error(err);
      setError("Error al cargar canciones");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchSongs();
  }, []);

  const handleChange = (e) => {
    setFormSong({ ...formSong, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");

    try {
      if (editingId) {
        const { data } = await axios.put(
          `${API_URL}/songs/${editingId}`,
          formSong
        );
        setSongs((prev) =>
          prev.map((s) => (s._id === editingId ? data : s))
        );
      } else {
        const { data } = await axios.post(`${API_URL}/songs`, formSong);
        setSongs((prev) => [...prev, data]);
      }
      setFormSong({ title: "", artist: "", fileUrl: "" });
      setEditingId(null);
    } catch (err) {
      console.error(err);
      setError("Error al guardar la canción");
    }
  };

  const handleEdit = (song) => {
    setEditingId(song._id);
    setFormSong({
      title: song.title,
      artist: song.artist,
      fileUrl: song.fileUrl,
    });
  };

  const handleDelete = async (id) => {
    if (!confirm("¿Seguro que quieres eliminar esta canción?")) return;
    try {
      await axios.delete(`${API_URL}/songs/${id}`);
      setSongs((prev) => prev.filter((s) => s._id !== id));
    } catch (err) {
      console.error(err);
      setError("Error al eliminar la canción");
    }
  };

  return (
    <div className="card">
      <div className="page-header">
        <h1>Canciones</h1>
        <span className="badge">CRUD • Canciones</span>
      </div>

      <p style={{ fontSize: "0.9rem", color: "#9ca3af", marginBottom: "1rem" }}>
        Ejemplo de CRUD completo (Create, Read, Update, Delete) para la colección
        <strong> canciones </strong> consumiendo la API de tu backend.
      </p>

      {error && (
        <p style={{ color: "#f97373", fontSize: "0.85rem", marginBottom: "0.5rem" }}>
          {error}
        </p>
      )}

      <SongForm
        song={formSong}
        onChange={handleChange}
        onSubmit={handleSubmit}
        isEditing={!!editingId}
      />

      {loading ? (
        <p style={{ marginTop: "1rem" }}>Cargando canciones...</p>
      ) : (
        <table className="table">
          <thead>
            <tr>
              <th>Título</th>
              <th>Artista</th>
              <th>MP3</th>
              <th>Acciones</th>
            </tr>
          </thead>
          <tbody>
            {songs.map((song) => (
              <tr key={song._id}>
                <td>{song.title}</td>
                <td>{song.artist}</td>
                <td>
                  {song.fileUrl && (
                    <audio controls src={song.fileUrl}>
                      Tu navegador no soporta el elemento audio.
                    </audio>
                  )}
                </td>
                <td>
                  <div style={{ display: "flex", gap: "0.4rem" }}>
                    <button
                      className="btn-secondary btn-sm"
                      onClick={() => handleEdit(song)}
                    >
                      Editar
                    </button>
                    <button
                      className="btn-danger btn-sm"
                      onClick={() => handleDelete(song._id)}
                    >
                      Eliminar
                    </button>
                  </div>
                </td>
              </tr>
            ))}
            {songs.length === 0 && !loading && (
              <tr>
                <td colSpan={4} style={{ color: "#9ca3af", fontSize: "0.9rem" }}>
                  No hay canciones registradas aún.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      )}
    </div>
  );
};

export default Songs;
