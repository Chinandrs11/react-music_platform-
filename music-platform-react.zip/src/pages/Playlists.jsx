import React, { useEffect, useState } from "react";
import axios from "axios";
import { useAuth } from "../context/AuthContext";
import PlaylistForm from "../components/PlaylistForm";

const Playlists = () => {
  const { API_URL } = useAuth();
  const [playlists, setPlaylists] = useState([]);
  const [songs, setSongs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [editingId, setEditingId] = useState(null);
  const [formPlaylist, setFormPlaylist] = useState({
    name: "",
    description: "",
    songIds: [],
  });

  const fetchData = async () => {
    try {
      setLoading(true);
      const [plRes, songsRes] = await Promise.all([
        axios.get(`${API_URL}/playlists`),
        axios.get(`${API_URL}/songs`),
      ]);
      setPlaylists(plRes.data);
      setSongs(songsRes.data);
    } catch (err) {
      console.error(err);
      setError("Error al cargar playlists");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleChange = (e) => {
    setFormPlaylist({ ...formPlaylist, [e.target.name]: e.target.value });
  };

  const handleSongToggle = (songId) => {
    setFormPlaylist((prev) => {
      const already = prev.songIds.includes(songId);
      return {
        ...prev,
        songIds: already
          ? prev.songIds.filter((id) => id !== songId)
          : [...prev.songIds, songId],
      };
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");

    try {
      if (editingId) {
        const { data } = await axios.put(
          `${API_URL}/playlists/${editingId}`,
          formPlaylist
        );
        setPlaylists((prev) =>
          prev.map((p) => (p._id === editingId ? data : p))
        );
      } else {
        const { data } = await axios.post(`${API_URL}/playlists`, formPlaylist);
        setPlaylists((prev) => [...prev, data]);
      }
      setFormPlaylist({ name: "", description: "", songIds: [] });
      setEditingId(null);
    } catch (err) {
      console.error(err);
      setError("Error al guardar la playlist");
    }
  };

  const handleEdit = (pl) => {
    setEditingId(pl._id);
    setFormPlaylist({
      name: pl.name,
      description: pl.description || "",
      songIds: pl.songs ? pl.songs.map((s) => s._id || s) : [],
    });
  };

  const handleDelete = async (id) => {
    if (!confirm("¿Seguro que quieres eliminar esta playlist?")) return;
    try {
      await axios.delete(`${API_URL}/playlists/${id}`);
      setPlaylists((prev) => prev.filter((p) => p._id !== id));
    } catch (err) {
      console.error(err);
      setError("Error al eliminar la playlist");
    }
  };

  const getSongName = (id) => {
    const song = songs.find((s) => s._id === id || s.id === id);
    return song ? `${song.title} – ${song.artist}` : "Canción";
  };

  return (
    <div className="card">
      <div className="page-header">
        <h1>Playlists</h1>
        <span className="badge">CRUD • Playlists</span>
      </div>

      <p style={{ fontSize: "0.9rem", color: "#9ca3af", marginBottom: "1rem" }}>
        Ejemplo de CRUD para la colección <strong>playlists</strong>, asignando
        canciones a cada lista de reproducción.
      </p>

      {error && (
        <p style={{ color: "#f97373", fontSize: "0.85rem", marginBottom: "0.5rem" }}>
          {error}
        </p>
      )}

      <PlaylistForm
        playlist={formPlaylist}
        onChange={handleChange}
        onSubmit={handleSubmit}
        isEditing={!!editingId}
      />

      <div style={{ marginTop: "1rem" }}>
        <p style={{ fontSize: "0.85rem", color: "#9ca3af", marginBottom: "0.5rem" }}>
          Selecciona las canciones que quieres agregar a la playlist:
        </p>
        <div
          style={{
            display: "grid",
            gap: "0.3rem",
            maxHeight: "200px",
            overflowY: "auto",
            borderRadius: "0.75rem",
            border: "1px solid #1f2937",
            padding: "0.5rem 0.75rem",
          }}
        >
          {songs.map((song) => (
            <label
              key={song._id}
              style={{
                display: "flex",
                alignItems: "center",
                gap: "0.4rem",
                fontSize: "0.85rem",
              }}
            >
              <input
                type="checkbox"
                checked={formPlaylist.songIds.includes(song._id)}
                onChange={() => handleSongToggle(song._id)}
                style={{ width: "auto" }}
              />
              <span>
                {song.title} – {song.artist}
              </span>
            </label>
          ))}
          {songs.length === 0 && (
            <span style={{ color: "#6b7280", fontSize: "0.85rem" }}>
              No hay canciones, primero crea algunas en la pestaña Canciones.
            </span>
          )}
        </div>
      </div>

      {loading ? (
        <p style={{ marginTop: "1rem" }}>Cargando playlists...</p>
      ) : (
        <table className="table">
          <thead>
            <tr>
              <th>Nombre</th>
              <th>Descripción</th>
              <th>Canciones</th>
              <th>Acciones</th>
            </tr>
          </thead>
          <tbody>
            {playlists.map((pl) => (
              <tr key={pl._id}>
                <td>{pl.name}</td>
                <td>{pl.description}</td>
                <td>
                  {pl.songs && pl.songs.length > 0 ? (
                    <ul style={{ paddingLeft: "1rem", fontSize: "0.85rem" }}>
                      {pl.songs.map((s) => (
                        <li key={s._id || s}>
                          {s.title
                            ? `${s.title} – ${s.artist}`
                            : getSongName(s)}
                        </li>
                      ))}
                    </ul>
                  ) : (
                    <span style={{ color: "#6b7280", fontSize: "0.85rem" }}>
                      (Sin canciones)
                    </span>
                  )}
                </td>
                <td>
                  <div style={{ display: "flex", gap: "0.4rem" }}>
                    <button
                      className="btn-secondary btn-sm"
                      onClick={() => handleEdit(pl)}
                    >
                      Editar
                    </button>
                    <button
                      className="btn-danger btn-sm"
                      onClick={() => handleDelete(pl._id)}
                    >
                      Eliminar
                    </button>
                  </div>
                </td>
              </tr>
            ))}
            {playlists.length === 0 && !loading && (
              <tr>
                <td colSpan={4} style={{ color: "#9ca3af", fontSize: "0.9rem" }}>
                  No hay playlists registradas aún.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      )}
    </div>
  );
};

export default Playlists;
