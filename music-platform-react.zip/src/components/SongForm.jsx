import React from "react";

const SongForm = ({ song, onChange, onSubmit, isEditing }) => {
  return (
    <form onSubmit={onSubmit}>
      <div className="grid-2">
        <div>
          <label htmlFor="title">Título</label>
          <input
            id="title"
            name="title"
            value={song.title}
            onChange={onChange}
            placeholder="Nombre de la canción"
            required
          />
        </div>
        <div>
          <label htmlFor="artist">Artista</label>
          <input
            id="artist"
            name="artist"
            value={song.artist}
            onChange={onChange}
            placeholder="Nombre del artista"
            required
          />
        </div>
      </div>
      <div>
        <label htmlFor="fileUrl">URL del MP3</label>
        <input
          id="fileUrl"
          name="fileUrl"
          value={song.fileUrl}
          onChange={onChange}
          placeholder="https://.../archivo.mp3"
          required
        />
      </div>
      <button className="btn-primary" type="submit">
        {isEditing ? "Actualizar canción" : "Agregar canción"}
      </button>
    </form>
  );
};

export default SongForm;
