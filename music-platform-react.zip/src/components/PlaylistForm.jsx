import React from "react";

const PlaylistForm = ({ playlist, onChange, onSubmit, isEditing }) => {
  return (
    <form onSubmit={onSubmit}>
      <div>
        <label htmlFor="name">Nombre de la playlist</label>
        <input
          id="name"
          name="name"
          value={playlist.name}
          onChange={onChange}
          placeholder="Mi playlist"
          required
        />
      </div>
      <div>
        <label htmlFor="description">Descripción (opcional)</label>
        <input
          id="description"
          name="description"
          value={playlist.description}
          onChange={onChange}
          placeholder="Playlist para estudiar, hacer ejercicio, etc."
        />
      </div>
      <button className="btn-primary" type="submit">
        {isEditing ? "Actualizar playlist" : "Crear playlist"}
      </button>
    </form>
  );
};

export default PlaylistForm;
