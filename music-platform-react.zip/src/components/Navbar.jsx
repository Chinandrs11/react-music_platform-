import React from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

const Navbar = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const { user, logout } = useAuth();

  const isActive = (path) =>
    location.pathname === path ? "nav-link nav-link-active" : "nav-link";

  const handleLogout = () => {
    logout();
    navigate("/login");
  };

  return (
    <header className="navbar">
      <div className="navbar-left">
        <div className="logo-circle" />
        <div>
          <div style={{ fontWeight: 700, fontSize: "0.95rem", color: "#f9fafb" }}>
            Music Platform
          </div>
          <div style={{ fontSize: "0.75rem", color: "#9ca3af" }}>
            CRUD + Login • React
          </div>
        </div>
      </div>

      <nav className="nav-links">
        {user && (
          <>
            <Link to="/songs" className={isActive("/songs")}>
              Canciones
            </Link>
            <Link to="/playlists" className={isActive("/playlists")}>
              Playlists
            </Link>
          </>
        )}
      </nav>

      <div className="nav-user">
        {user ? (
          <>
            <span>{user.name || user.email}</span>
            <button className="btn-secondary btn-sm" onClick={handleLogout}>
              Cerrar sesión
            </button>
          </>
        ) : (
          <>
            <Link to="/login" className="nav-link">
              Iniciar sesión
            </Link>
            <Link to="/register" className="nav-link">
              Registrarme
            </Link>
          </>
        )}
      </div>
    </header>
  );
};

export default Navbar;
