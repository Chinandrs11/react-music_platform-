import React from "react";
import { Routes, Route, Navigate } from "react-router-dom";
import { useAuth } from "./context/AuthContext";
import Navbar from "./components/Navbar";
import Login from "./pages/Login";
import Register from "./pages/Register";
import Songs from "./pages/Songs";
import Playlists from "./pages/Playlists";

const PrivateRoute = ({ children }) => {
  const { token, loading } = useAuth();

  if (loading) return <p style={{ padding: "1rem" }}>Cargando...</p>;

  if (!token) return <Navigate to="/login" replace />;

  return children;
};

function App() {
  return (
    <div className="app-container">
      <Navbar />
      <main>
        <Routes>
          <Route path="/" element={<Navigate to="/songs" replace />} />
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
          <Route
            path="/songs"
            element={
              <PrivateRoute>
                <Songs />
              </PrivateRoute>
            }
          />
          <Route
            path="/playlists"
            element={
              <PrivateRoute>
                <Playlists />
              </PrivateRoute>
            }
          />
        </Routes>
      </main>
    </div>
  );
}

export default App;
